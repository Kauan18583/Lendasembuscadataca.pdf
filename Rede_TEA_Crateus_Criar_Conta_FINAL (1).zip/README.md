# Rede TEA Crateús — Protótipo funcional ampliado

Protótipo front-end em HTML5 + JavaScript + Bootstrap 5, baseado no PDF do desafio.

## Novos recursos
- Retirada de pacientes da fila/serviço, preservando o histórico.
- Registro do motivo e observação da retirada.
- Tela de atendimentos com comparecimento/falta.
- Declaração de transferência entre serviços, com pré-visualização e impressão.
- Botões de acesso à transferência diretamente no cadastro do paciente.
- Formulários ampliados para as fichas de anamnese psicológica, psicopedagógica, instrumental da educadora física e síntese de acompanhamento.
- Campos de encaminhamento, prioridade, histórico e rede de serviços.

## Como executar
Abra `index.html` no navegador.

## Limite do protótipo
Os dados são demonstrativos e ficam em memória durante a sessão. Para produção, é indispensável backend + banco de dados, autenticação, perfis/permissões, logs de auditoria, criptografia, política de retenção e adequação à LGPD.


## Atualização desta versão
- Mantida a estrutura e funcionalidades anteriores.
- Incluído login de funcionário antes do acesso ao sistema.
- Motivo da transferência passa a ser salvo no `localStorage` do navegador e restaurado após atualizar a página.
- O motivo também aparece na declaração emitida.
- Removida a seção visual específica que dizia “LGPD”; a referência legal permanece de forma discreta: Lei nº 13.709/2018.
- Observação: as credenciais do login são apenas demonstrativas, pois este protótipo é front-end e não possui servidor de autenticação.
